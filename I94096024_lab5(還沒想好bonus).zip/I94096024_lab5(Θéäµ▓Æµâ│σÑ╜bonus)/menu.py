import pygame
import os

UpgradeMenu_Image = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade_menu.png")),(200, 200))
Upgrade_Image = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade.png")), (50,50))
Sell_Image = pygame.transform.scale(pygame.image.load(os.path.join("images", "sell.png")),(50,50))

class UpgradeMenu:
    def __init__(self, x, y):
        self.menu_image = UpgradeMenu_Image
        self.rect = self.menu_image.get_rect()#(x,y,width,hieght)
        self.rect.centerx = x
        self.rect.centery = y 
        # (Q2) Add buttons here
        self.__buttons = [Button(UpgradeMenu_Image, "upgrade", self.rect.centerx, self.rect.centery-75), 
                          Button(Sell_Image, "sell",self.rect.centerx, self.rect.centery+75)]  

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.menu_image,(self.rect.x, self.rect.y))#通通對其左上角
         # (Q2) Draw buttons here
        win.blit(Upgrade_Image,(self.rect.x+70, self.rect.y))
        win.blit(Sell_Image,(self.rect.x+70, self.rect.y+150))
        
    
    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        
        #self.upgrade_image= Upgrade_Image 
        self.upgrade_image_rect = Upgrade_Image.get_rect()
        #self.sell_image = Sell_Image
        self.sell_image_rect = Sell_Image.get_rect()
        self.name = None
        
    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        # for more info about collidepoint: https://stackoverflow.com/questions/29640685/how-do-i-detect-collision-in-pygame 
        if self.upgrade_image_rect.collidepoint(x, y):
            return True 
            self.name = "upgrade"
        elif self.sell_image_rect.collidepoint(x, y):
            return True 
            self.name = "sell"
        else:
            return False
        
        

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        return self.name






